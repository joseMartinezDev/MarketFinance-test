﻿using Moq;
using FluentAssertions;
using Xunit;
using SlothEnterprise.ProductApplication.Interfaces;

namespace SlothEnterprise.ProductApplication.Tests
{
    public class ServiceFactoryTest
    {
        private readonly IServiceFactory _service_factory_test;

        public ServiceFactoryTest()
        {
            Mock<IServiceFactory> service_factory = new Mock<IServiceFactory>();
            service_factory.Setup(m => m.GetService()).Returns(It.IsAny<IService>());
            _service_factory_test = service_factory.Object;


        }

        [Fact]
        public void ServiceFactory_SubmitApplicationFor_WhenCalledWithSelectiveInvoiceDiscount_ShouldReturnOne()
        {

            IService result = _service_factory_test.GetService();
            result.Should().Be(It.IsAny<IService>());

        }

    }


}
