﻿using FluentAssertions;
using Moq;
using SlothEnterprise.ProductApplication.Applications;
using SlothEnterprise.ProductApplication.Products;
using SlothEnterprise.ProductApplication.Interfaces;
using Xunit;

namespace SlothEnterprise.ProductApplication.Tests
{
    public class ProductApplicationTests
    {
        private readonly IProductApplicationService _sut;
        private readonly ISellerApplication _sellerApplicationConfidentialInvoice;
        private readonly ISellerApplication _sellerApplicationSelectInvoice;
        private readonly ISellerApplication _sellerApplicationBusinessLoan;


        public ProductApplicationTests()
        {

            Mock<IProductApplicationService> productApplicationService = new Mock<IProductApplicationService>();
            _sut = productApplicationService.Object;
            productApplicationService.Setup(m => m.SubmitApplicationFor(It.IsAny<ISellerApplication>())).Returns(1);
            Mock<ISellerApplication> sellerApplicationMock = new Mock<ISellerApplication>();
            sellerApplicationMock.SetupProperty(p => p.Product, new ConfidentialInvoiceDiscount());
            sellerApplicationMock.SetupProperty(p => p.CompanyData, new SellerCompanyData());
            _sellerApplicationConfidentialInvoice = sellerApplicationMock.Object;

            sellerApplicationMock.SetupProperty(p => p.Product, new SelectiveInvoiceDiscount());
            sellerApplicationMock.SetupProperty(p => p.CompanyData, new SellerCompanyData());
            _sellerApplicationSelectInvoice = sellerApplicationMock.Object;

            sellerApplicationMock.SetupProperty(p => p.Product, new BusinessLoans());
            sellerApplicationMock.SetupProperty(p => p.CompanyData, new SellerCompanyData());
            _sellerApplicationBusinessLoan = sellerApplicationMock.Object;
        }

        [Fact]
        public void ProductApplicationService_SubmitApplicationFor_WhenCalledWithSelectiveInvoiceDiscount_ShouldReturnOne()
        {
            int result = _sut.SubmitApplicationFor(_sellerApplicationSelectInvoice);
            result.Should().Be(1);
        }

        [Fact]
        public void ProductApplicationService_SubmitApplicationFor_WhenCalledWithConfidentialInvoiceDiscount_ShouldReturnOne()
        {
            int result = _sut.SubmitApplicationFor(_sellerApplicationConfidentialInvoice);
            result.Should().Be(1);
        }

        [Fact]
        public void ProductApplicationService_SubmitApplicationFor_WhenCalledWithBusinessLoan_ShouldReturnOne()
        {
            int result = _sut.SubmitApplicationFor(_sellerApplicationBusinessLoan);
            result.Should().Be(1);
        }
    }
}