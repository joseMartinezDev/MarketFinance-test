﻿using Moq;
using FluentAssertions;
using Xunit;
using SlothEnterprise.ProductApplication.Applications;
using SlothEnterprise.ProductApplication.Products;
using SlothEnterprise.ProductApplication.Interfaces;

namespace SlothEnterprise.ProductApplication.Tests
{
    public class ServiceTest
    {
        private readonly IService _service_test;
        private readonly ISellerApplication _sellerApplicationConfidentialInvoice;
        private readonly ISellerApplication _sellerApplicationSelectInvoice;
        private readonly ISellerApplication _sellerApplicationBusinessLoans;

        public ServiceTest()
        {
            Mock<IService> service = new Mock<IService>();
            _service_test = service.Object;
            service.Setup(m => m.SubmitApplicationFor(It.IsAny<ISellerApplication>())).Returns(1);

            Mock<ISellerApplication> sellerApplicationMock = new Mock<ISellerApplication>();

            sellerApplicationMock.SetupProperty(p => p.Product, new ConfidentialInvoiceDiscount());
            sellerApplicationMock.SetupProperty(p => p.CompanyData, new SellerCompanyData());
            _sellerApplicationConfidentialInvoice = sellerApplicationMock.Object;


            sellerApplicationMock.SetupProperty(p => p.Product, new SelectiveInvoiceDiscount());
            sellerApplicationMock.SetupProperty(p => p.CompanyData, new SellerCompanyData());
            _sellerApplicationSelectInvoice = sellerApplicationMock.Object;


            sellerApplicationMock.SetupProperty(p => p.Product, new BusinessLoans());
            sellerApplicationMock.SetupProperty(p => p.CompanyData, new SellerCompanyData());
            _sellerApplicationBusinessLoans = sellerApplicationMock.Object;
        }

        [Fact]
        public void Service_SubmitApplicationFor_WhenCalledWithConfidentialInvoiceDiscount_ShouldReturnOne()
        {
            int result = _service_test.SubmitApplicationFor(_sellerApplicationConfidentialInvoice);
            result.Should().Be(1);
        }

        [Fact]
        public void Service_SubmitApplicationFor_WhenCalledWithSelectInvoiceDiscount_ShouldReturnOne()
        {
            int result = _service_test.SubmitApplicationFor(_sellerApplicationSelectInvoice);
            result.Should().Be(1);
        }

        [Fact]
        public void Service_SubmitApplicationFor_WhenCalledWithBusinessLoans_ShouldReturnOne()
        {
            int result = _service_test.SubmitApplicationFor(_sellerApplicationBusinessLoans);
            result.Should().Be(1);
        }


    }


}
