﻿using SlothEnterprise.ProductApplication.Applications;

namespace SlothEnterprise.ProductApplication.Interfaces
{
    public interface IProductApplicationService
    {
        int SubmitApplicationFor(ISellerApplication application);
    }
}