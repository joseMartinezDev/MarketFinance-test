﻿using SlothEnterprise.ProductApplication.Interfaces;

namespace SlothEnterprise.ProductApplication

{
    public interface IServiceFactory
    {
        IService GetService();
    }
}
