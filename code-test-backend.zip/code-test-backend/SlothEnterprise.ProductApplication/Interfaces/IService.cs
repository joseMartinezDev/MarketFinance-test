﻿using SlothEnterprise.ProductApplication.Applications;

namespace SlothEnterprise.ProductApplication.Interfaces
{
    public interface IService
    {

        int SubmitApplicationFor(ISellerApplication _application);

    }
}
