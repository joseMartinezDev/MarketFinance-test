﻿using SlothEnterprise.External.V1;
using SlothEnterprise.ProductApplication.Applications;
using SlothEnterprise.ProductApplication.Interfaces;

namespace SlothEnterprise.ProductApplication.Implementations
{
    public class ProductApplicationService : IProductApplicationService
    {

        private readonly ServiceFactory _serviceFactory;


        public ProductApplicationService(ISelectInvoiceService selectInvoiceService, IConfidentialInvoiceService confidentialInvoiceWebService, IBusinessLoansService businessLoansService)
        {
            _serviceFactory = new ServiceFactory(selectInvoiceService, confidentialInvoiceWebService, businessLoansService);
        }



        public int SubmitApplicationFor(ISellerApplication application)
        {

            return _serviceFactory.GetService().SubmitApplicationFor(application);


        }
    }
}
