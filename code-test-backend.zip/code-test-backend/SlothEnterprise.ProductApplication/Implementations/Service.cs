﻿using System;
using SlothEnterprise.ProductApplication.Applications;
using SlothEnterprise.ProductApplication.Products;
using SlothEnterprise.External.V1;
using SlothEnterprise.External;
using SlothEnterprise.ProductApplication.Interfaces;


namespace SlothEnterprise.ProductApplication.Implementations
{
    internal class Service : IService
    {

        private readonly ISelectInvoiceService _selectInvoiceService;
        private readonly IConfidentialInvoiceService _confidentialInvoiceWebService;
        private readonly IBusinessLoansService _businessLoansService;

        public Service(ISelectInvoiceService selectInvoiceService, IConfidentialInvoiceService confidentialInvoiceWebService, IBusinessLoansService businessLoansService)
        {
            _selectInvoiceService = selectInvoiceService;
            _confidentialInvoiceWebService = confidentialInvoiceWebService;
            _businessLoansService = businessLoansService;

        }

        public int SubmitApplicationFor(ISellerApplication _application)
        {
            if (_application.Product is SelectiveInvoiceDiscount sid)
            {
                return _selectInvoiceService.SubmitApplicationFor(_application.CompanyData.Number.ToString(), sid.InvoiceAmount, sid.AdvancePercentage);
            }
            else if (_application.Product is ConfidentialInvoiceDiscount cid)
            {
                IApplicationResult result = _confidentialInvoiceWebService.SubmitApplicationFor(
                    new CompanyDataRequest
                    {
                        CompanyFounded = _application.CompanyData.Founded,
                        CompanyNumber = _application.CompanyData.Number,
                        CompanyName = _application.CompanyData.Name,
                        DirectorName = _application.CompanyData.DirectorName
                    }, cid.TotalLedgerNetworth, cid.AdvancePercentage, cid.VatRate);

                return result.Success ? result.ApplicationId ?? -1 : -1;

            }

            else if (_application.Product is BusinessLoans loans)
            {
                IApplicationResult result = _businessLoansService.SubmitApplicationFor(new CompanyDataRequest
                {
                    CompanyFounded = _application.CompanyData.Founded,
                    CompanyNumber = _application.CompanyData.Number,
                    CompanyName = _application.CompanyData.Name,
                    DirectorName = _application.CompanyData.DirectorName
                }, new LoansRequest
                {
                    InterestRatePerAnnum = loans.InterestRatePerAnnum,
                    LoanAmount = loans.LoanAmount
                });
                return result.Success ? result.ApplicationId ?? -1 : -1;
            }
            else
            {
                throw new InvalidOperationException();
            }

        }
    }
}
