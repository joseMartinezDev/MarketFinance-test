1. First of all, we should have a parent interface for every service we are implementing, so the code would be extensible and easier to read.

2. All the services should return the same, so the code would be more consistent and easier to maintain and debug.
If we follow the advice number 1 this would be automatically achieved.

3. There is no implementation of the services, so right now this API is useless.

4. Error handling. In the implementation of the services, there should be a proper error handling.

5. We are using both SellerCompanyData and the product itself to store the data needed by each Product, we should store the data in
just one object, then it would be easier to maintain are to read.
Again, this has to do with advice number 1.

6. Testing. As we don't have the actual implementation of the services, currently, testing is not very useful, apart from making sure
that the interfaces return the expected type.

7. In order to make it extensible, I propose a ServiceFactory instead of doing the routing in SubmitApplicationFor
